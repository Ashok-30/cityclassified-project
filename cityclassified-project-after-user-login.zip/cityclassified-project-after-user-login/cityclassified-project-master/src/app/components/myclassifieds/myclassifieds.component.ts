import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myclassifieds',
  templateUrl: './myclassifieds.component.html',
  styleUrls: ['./myclassifieds.component.css']
})
export class MyclassifiedsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
