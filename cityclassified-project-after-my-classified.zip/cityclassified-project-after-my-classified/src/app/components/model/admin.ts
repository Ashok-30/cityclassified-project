export interface Admin{
    id: number;
    adminName: string;
}